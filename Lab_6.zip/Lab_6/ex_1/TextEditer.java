package Lab_6.ex_1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TextEditer 
{
    List<String> collected = new ArrayList<>();

    public void inportText(Scanner scanner) 
    {
        System.out.println("Enter your input, one line at a time. Type 'exit' to finish.");

        while (true) 
            {
            if (!scanner.hasNextLine()) {
                return;
            }
            String line = scanner.nextLine();
            if (line.equals("exit")) 
                {
                break;
                }
            collected.add(line);
            }
    }

    public boolean replaceText(String searchTerm, String replacement) 
    {
        for (int i = 0; i < collected.size(); i++) 
        {
            String line = collected.get(i);
            if (line.contains(searchTerm)) 
            {
                String replacedLine = line.replace(searchTerm, replacement);
                collected.set(i, replacedLine);
                return true;
            }
        }
        return false;
    }

    public void getStats()
    {
        int counter = 0;
        for (int i = 0; i < collected.size(); i++) 
        {
            Pattern pattern = Pattern.compile("[^\\s@]+@[^\\s@]+\\.[^\\s@]+");
            Matcher matcher = pattern.matcher(collected.get(i));
            while (matcher.find()) 
            {
                counter++;
            }
        }

        if(counter > 0) 
        {
            System.out.println("Match found: " + counter);
        }
        else 
        {
            System.out.println("Match not found");
        }
    }

    public StringBuilder emailBuilder()
    {
        StringBuilder emailList = new StringBuilder();
        for (int i = 0; i < collected.size(); i++) 
        {
            Pattern pattern = Pattern.compile("[^\\s@]+@[^\\s@]+\\.[^\\s@]+");
            Matcher matcher = pattern.matcher(collected.get(i));
            while (matcher.find()) 
            {
                emailList.append(matcher.group()).append("\n");
            }
        }
        return emailList;
    }

    public void flipText() 
    {
        for (int i = 0; i < collected.size(); i++) 
        {
            String newLine = new String();
            String myStr = collected.get(i);
            String regex = ",|\\.|\\s";
            String[] myArray = myStr.split(regex);

            for (int j = myArray.length - 1; j >= 0; j--) 
            {
                newLine += myArray[j] + " ";
            }
            collected.set(i, newLine);
        }
    }

    public void printText() 
    {
        for (String line : collected) 
        {
            System.out.println(line);
        }
    }

    public List<String> getCollected() 
    {
        return collected;
    }

    public void setCollected(List<String> collected) 
    {
        this.collected = collected;
    }

    public String getText() 
    {
        StringBuilder content = new StringBuilder();
        for (String line : collected) 
        {
            content.append(line).append("\n");
        }
        return content.toString();
    }

    
}
