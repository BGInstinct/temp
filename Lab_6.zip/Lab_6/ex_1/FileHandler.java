package Lab_6.ex_1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Scanner;
import java.nio.CharBuffer;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.nio.charset.Charset;
    

public class FileHandler 
{
    public boolean saveToFile(String filename, String content) 
    {
        String filePath = "files/" + filename;
        try {
            File file = new File(filePath);
            if(file.exists()) 
            {
                System.out.println("File already exists. Overwriting...");
                file.delete();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
            }
        try {
            FileWriter writer = new FileWriter(filePath);
            writer.write(content);
            writer.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
            }
    }

    public List<String> readFromFile(String filename) 
    {
        String filePath = "files/" + filename;
        StringBuilder content = new StringBuilder();
        try {
            File file = new File(filePath);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) 
            {
                content.append(scanner.nextLine()).append("\n");
            }
            scanner.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return List.of(content.toString().split("\n"));
    }

    public byte[] toBytes(char[] chars) {
      CharBuffer charBuffer = CharBuffer.wrap(chars);
      ByteBuffer byteBuffer = Charset.forName("UTF-8").encode(charBuffer);
      byte[] bytes = Arrays.copyOfRange(byteBuffer.array(),
                byteBuffer.position(), byteBuffer.limit());
      Arrays.fill(byteBuffer.array(), (byte) 0); // clear sensitive data
      return bytes;
    }

    public void saveEmailsToFile(String filename, StringBuilder emails) 
    {
        File file = getEmailFile(filename);
        try (OutputStream outputStream = new FileOutputStream(file)) {
            char[] charArray = emails.toString().toCharArray();
            byte[] byteArray = toBytes(charArray);
            outputStream.write(byteArray);
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public StringBuilder readEmailsFromFile(String filename) 
    {
        File file = getEmailFile(filename);
        try (InputStream inputStream = new FileInputStream(file)) {
            byte[] bytes = inputStream.readAllBytes();
            return new StringBuilder(new String(bytes, Charset.forName("UTF-8")));
        } catch (Exception e) {
            e.printStackTrace();
            return new StringBuilder();
        }
    }

    private File getEmailFile(String filename) {
        File localDirectory = new File("files");
        File packageDirectory = new File("Lab_6/ex_1/files");
        File directory = localDirectory.isDirectory() || !packageDirectory.isDirectory()
                ? localDirectory
                : packageDirectory;
        if (!directory.isDirectory() && !directory.mkdirs()) {
            throw new IllegalStateException("Could not create directory: " + directory);
        }
        String fileName = filename.endsWith(".bin") ? filename : filename + ".bin";
        return new File(directory, fileName);
    }
}
