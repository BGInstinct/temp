package Lab_6.ex_1;
import java.util.List;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        TextEditer text = new TextEditer();
        FileHandler fileHandler = new FileHandler();
        try (Scanner scanner = new Scanner(System.in)) {
        while (true) 
        {
            System.out.println("""
                1. Enter text
                2. Replace text
                3. Get stats
                4. Flip text
                5. print text
                6. Export text
                7. Import text from file
                8. Exit
                9. Save emails to file
                10. Print emails
                """);

            if (!scanner.hasNextLine()) {
                return;
            }
            String choice = scanner.nextLine();
            switch (choice) 
            {
                case "1":
                {
                    text.inportText(scanner);
                    break;
                }
                case "2":
                {
                    System.out.println("Enter the text to search for:");
                    String searchTerm = scanner.nextLine();
                    System.out.println("Enter the replacement text:");
                    String replacement = scanner.nextLine();
                    boolean replaced = text.replaceText(searchTerm, replacement);

                    if (replaced) 
                    {
                        System.out.println("Text replaced successfully.");
                    } 
                    else 
                    {
                        System.out.println("Text not found.");
                    }
                    break;
                }

                case "3":
                {
                    text.getStats();
                    break;
                }
                case "4":
                {
                    text.flipText();
                    break;
                }
                case "5":
                {
                    text.printText();
                    break;
                }
                case "6":
                {
                    System.out.println("Enter the filename to export to:");
                    String filename = scanner.nextLine();
                    fileHandler.saveToFile(filename, text.getText());
                    break;
                }
                case "7":
                {
                    System.out.println("Enter the filename to import from:");
                    String filename = scanner.nextLine();
                    List<String> importedText = fileHandler.readFromFile(filename);
                    text.setCollected(importedText);
                    break;
                }
                case "8":
                {
                    System.out.println("Exiting...");
                    return;
                }
                case "9":
                {
                    System.out.println("Enter the filename to save emails to:");
                    String filename = scanner.nextLine();
                    StringBuilder emails = text.emailBuilder();
                    fileHandler.saveEmailsToFile(filename, emails);
                    break;
                }
                case "10":
                {
                    System.out.println("Enter the filename to save emails to:");
                    String filename = scanner.nextLine();
                    StringBuilder emails = fileHandler.readEmailsFromFile(filename);
                    System.out.println("Emails found:");
                    System.out.println(emails.toString());
                    break;
                }
                default:
                {
                    System.out.println("Invalid option. Please try again.");
                    break;
                }
            }
        }
        }
    }
}
